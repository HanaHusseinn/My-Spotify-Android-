package com.example.myapplicationproj;

import java.util.ArrayList;

public class Reponse {

    ArrayList<model> tracks;


    public ArrayList<model> getTracks(){
        return tracks;
    }
    public void setTracks(ArrayList<model> tracks){
        this.tracks=tracks;
    }

}
